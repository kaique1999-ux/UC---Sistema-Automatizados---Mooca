#include <DHT.h>

const int BTN = 2;
const int LED = 8;
const int POT = A0;

#define DHTPIN 4
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  pinMode(BTN, INPUT_PULLUP);
  pinMode(LED, OUTPUT);

  Serial.begin(9600);

  dht.begin();
}

void loop() {

  // BOTÃO + LED
  bool detectado = digitalRead(BTN) == LOW;
  digitalWrite(LED, detectado);

  // POTENCIÔMETRO
  int bruto = analogRead(POT);

  // DHT22
  float t = dht.readTemperature();

  // CLASSIFICAÇÃO DO SISTEMA
  if (isnan(t)) {
    Serial.println("FALHA DE SENSOR");
  } 
  else if (t >= 40 || bruto >= 750) {
    Serial.println("ALARME");
  } 
  else if (t >= 30 || bruto >= 400) {
    Serial.println("ATENCAO");
  } 
  else {
    Serial.println("NORMAL");
  }

  // MOSTRA A TEMPERATURA
  Serial.println(t);

  delay(1000);
}